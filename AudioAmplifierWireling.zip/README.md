# TinyCircuits Audio Amplifier Wireling Example

A simple example of playing audio using the SAMD21 and an Audio Amplifier Wireling.

* "hi" audio sample: https://www.youtube.com/watch?v=NTJ7RiByZGo
* Software to convert any audio to uncompressed raw unsigned 8-bit mono: Audacity
* Software to convert .raw to C header file: bin2header